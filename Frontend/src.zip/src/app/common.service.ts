import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  isLoggedIn: boolean = false;
  role: string = '';
  username: string = '';
  private loggedInUserId: number | null = null;

  constructor(private router: Router) { 
    if (typeof localStorage !== 'undefined') {
      const token = localStorage.getItem('token');
      const storedUsername = localStorage.getItem('username'); // Load username
      const storedUserId = localStorage.getItem('userId');
      if (token) {
        this.isLoggedIn = true; // If a token exists, assume logged in
      }
      if (storedUsername) {
        this.username = storedUsername; // Set username from localStorage
      }
      if (storedUserId) {
        this.loggedInUserId = parseInt(storedUserId, 10); // Parse to number
      }
    }

    if (typeof sessionStorage !== 'undefined') {
      const storedRole = sessionStorage.getItem('role');
      if (storedRole) {
        this.role = storedRole; // Set role from session storage
      }
    }
  }
  // Method to set login state and user details
  setLoginState(token: string, role: string, username: string, userId: number): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('token', token);
      localStorage.setItem('username', username);
      localStorage.setItem('userId', userId.toString()); // Save userId as string
    }
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.setItem('role', role);
    }
    this.isLoggedIn = true;
    this.role = role;
    this.username = username;
    this.loggedInUserId = userId;
  }

  // Method to clear login state
  clearLoginState(): void {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('token');
      localStorage.removeItem('username');
      localStorage.removeItem('userId');
    }
    if (typeof sessionStorage !== 'undefined') {
      sessionStorage.removeItem('role');
    }
    this.isLoggedIn = false;
    this.role = '';
    this.username = '';
    this.loggedInUserId = null;
  }

  // New method to get the logged-in user ID
  getLoggedInUserId(): number | null {
    return this.loggedInUserId;
  }

  getUsername(): string | null {
    return this.username;
  }
}
