import { CommonModule, DatePipe, NgFor } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { OrdersService } from '../orders.service';
import { CommonService } from '../common.service';
import { FormsModule } from '@angular/forms';
import { UsersService, UserProfile } from '../users.service';
import { forkJoin, Observable } from 'rxjs';

interface DisplayOrder {
  id: number;
  date: Date;
  total: number;
  status: string;
  paymentStatus: string;
  shippingAddress: string;
  items: {
    productId: number;
    name: string;
    quantity: number;
    price: number;
  }[];
  userId: number;
  userName?: string;
  isEditingStatus?: boolean;
  selectedStatus?: string;
}

@Component({
  selector: 'app-orders',
  imports: [CommonModule, NgFor, DatePipe, RouterLink, FormsModule],
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.css'
})
export class OrdersComponent implements OnInit {

  orders: DisplayOrder[] = [];
  loggedInUserId: number | null = null;
  userRole: string | null = null;

  orderStatuses: string[] = ['Placed', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

  constructor(private ordersService: OrdersService, private commonService: CommonService, private usersService: UsersService) { }

  ngOnInit(): void {
    this.loggedInUserId = this.commonService.getLoggedInUserId();
    this.userRole = this.commonService.role;

    if (!this.loggedInUserId) {
      alert('Please log in to view your orders.');
      return;
    }

    if (this.userRole === 'ADMIN') {
      this.fetchAllOrdersForAdmin();
    } else {
      this.fetchOrdersForUser();
    }
  }

  fetchOrdersForUser(): void {
    if (this.loggedInUserId) {
      this.ordersService.getOrdersByUserId(this.loggedInUserId).subscribe({
        next: (data: any[]) => {
          console.log('Raw data from backend (getOrdersByUserId):', data);
          this.orders = this.mapOrderDetailsToDisplayOrders(data);
          console.log('Mapped user orders for display:', this.orders);
        },
        error: (err) => {
          console.error('Error fetching user orders:', err);
          alert('Failed to load your orders. Please try again.');
          this.orders = [];
        }
      });
    }
  }

  fetchAllOrdersForAdmin(): void {
    this.ordersService.getAllOrders().subscribe({
      next: (data: any[]) => {
        console.log('Raw data from backend (getAllOrders - with items):', data);

        // **HIGHLIGHT START: Process orders and fetch user names**
        const orderObservables: Observable<DisplayOrder>[] = data.map((orderDto: any) => {
          const baseOrder: DisplayOrder = {
            id: orderDto.orderId,
            date: new Date(orderDto.orderDate),
            total: orderDto.totalPrice,
            status: orderDto.orderStatus,
            paymentStatus: orderDto.paymentStatus,
            shippingAddress: orderDto.shippingAddress,
            userId: orderDto.userId,
            items: orderDto.items.map((item: any) => ({
              productId: item.productId,
              name: item.productName,
              quantity: item.quantity,
              price: item.priceAtOrder
            })),
            isEditingStatus: false,
            selectedStatus: orderDto.orderStatus
          };

          // For each order, fetch the user's name
          return this.usersService.getUserById(orderDto.userId).pipe(
            (obs) => { // Using pipe for more readable transformations within RxJS
              return new Observable<DisplayOrder>(subscriber => {
                obs.subscribe({
                  next: (userProfile: UserProfile) => {
                    baseOrder.userName = userProfile.name; // Add the username
                    subscriber.next(baseOrder);
                    subscriber.complete();
                  },
                  error: (userError) => {
                    console.warn(`Could not fetch user name for userId ${orderDto.userId}:`, userError);
                    baseOrder.userName = 'Unknown User'; // Set a default if fetching fails
                    subscriber.next(baseOrder); // Still emit the order even if user fetch fails
                    subscriber.complete();
                  }
                });
              });
            }
          );
        });

        // Use forkJoin to wait for all user name fetches to complete
        forkJoin(orderObservables).subscribe({
          next: (processedOrders: DisplayOrder[]) => {
            this.orders = processedOrders;
            console.log('Mapped all orders for admin (with user names):', this.orders);
          },
          error: (err) => {
            console.error('Error processing orders with user names:', err);
            alert('Failed to load all orders with user details. Please try again.');
            this.orders = [];
          }
        });
        // **HIGHLIGHT END**

      },
      error: (err) => {
        console.error('Error fetching all orders for admin:', err);
        alert('Failed to load all orders. Please try again.');
        this.orders = [];
      }
    });
  }

  mapOrderDetailsToDisplayOrders(data: any[]): DisplayOrder[] {
    return data.map((orderDto: any) => ({
        id: orderDto.orderId,
        date: new Date(orderDto.orderDate),
        total: orderDto.totalPrice,
        status: orderDto.orderStatus,
        paymentStatus: orderDto.paymentStatus,
        shippingAddress: orderDto.shippingAddress,
        userId: orderDto.userId,
        items: orderDto.items.map((item: any) => ({
            productId: item.productId,
            name: item.productName,
            quantity: item.quantity,
            price: item.priceAtOrder
        })),
        isEditingStatus: false,
        selectedStatus: orderDto.orderStatus
    }));
  }

  toggleEditStatus(order: DisplayOrder): void {
    order.isEditingStatus = !order.isEditingStatus;
    if (order.isEditingStatus) {
      order.selectedStatus = order.status;
    }
  }

  updateOrderStatus(order: DisplayOrder): void {
    if (order.selectedStatus) {
      const updatedOrderPayload: any = {
        orderId: order.id,
        orderStatus: order.selectedStatus
      };

      this.ordersService.updateOrder(updatedOrderPayload).subscribe({
        next: (res: any) => {
          console.log('Order status updated successfully:', res);
          order.status = res.orderStatus;
          order.isEditingStatus = false;
          alert('Order status updated to ' + res.orderStatus);
        },
        error: (err) => {
          console.error('Error updating order status:', err);
          const errorMessage = err.error?.message || 'Server error. Please check backend logs.';
          alert('Failed to update order status: ' + errorMessage);
        }
      });
    }
  }
}