import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonService } from '../common.service';
import { UserProfile, UsersService } from '../users.service';

@Component({
  selector: 'app-profile',
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit{

  currentUserProfile: UserProfile = {
    userId: 0,
    name: '',
    email: '',
    phoneNumber: '',
    shippingAddress: ''
  };

  constructor(private router: Router, private commonService: CommonService, private usersService: UsersService) { }
  ngOnInit(): void {
    const userId = this.commonService.getLoggedInUserId();
    if (userId) {
      this.fetchUserProfile(userId);
    } else {
      alert('You are not logged in. Please login to view your profile.');
      this.router.navigate(['/login']);
    }
  }

  fetchUserProfile(userId: number): void {
    this.usersService.getUserById(userId).subscribe({
      next: (data: UserProfile) => {
        this.currentUserProfile = data;
      },
      error: (err) => {
        console.error('Error fetching user profile:', err);
        alert('Failed to load your profile. Please try again.');
        this.router.navigate(['/home']); // Redirect or handle error appropriately
      }
    });
  }

  saveProfile(): void {
    if (this.currentUserProfile.userId) {
      this.usersService.updateUser(this.currentUserProfile).subscribe({
        next: (updatedUser: UserProfile) => {
          alert('Profile updated successfully!');
          console.log('Updated user profile:', updatedUser);
          // Optionally update username in CommonService if name changed
          if (this.commonService.username !== updatedUser.name) {
            this.commonService.username = updatedUser.name;
            localStorage.setItem('username', updatedUser.name);
          }
          this.router.navigate(['/home']); // Navigate back or to a success page
        },
        error: (err) => {
          console.error('Error updating profile:', err);
          const errorMessage = err.error?.message || err.error?.details || 'Failed to update profile.';
          alert('Failed to update profile: ' + errorMessage);
        }
      });
    } else {
      alert('Cannot update profile: User ID is missing.');
    }
  }
}