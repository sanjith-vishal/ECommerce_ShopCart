import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  private apiUrl = 'http://localhost:9090/product'; // Your backend URL

  constructor(private http: HttpClient) { }

  // Helper method to get headers with JWT token directly from localStorage
  private getAuthHeaders(): HttpHeaders {
    let token: string | null = null;
    if (typeof localStorage !== 'undefined') { // Safely check for localStorage
      token = localStorage.getItem('token'); // Get token using the key "token" from localStorage
    }

    let headers = new HttpHeaders();
    if (token) {
      headers = headers.set('Authorization', 'Bearer ' + token);
    }
    return headers;
  }

  // --- CORRECTED METHODS: NOW PASSING HEADERS ---

  getAllProducts(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/fetchAll`, { headers: this.getAuthHeaders() });
  }

  getProductsByCategory(category: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/category/${category}`, { headers: this.getAuthHeaders() });
  }

  getProductsByPriceRange(min: number, max: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/price-range/${min}/${max}`, { headers: this.getAuthHeaders() });
  }

  // Admin specific methods
  saveProduct(product: any): Observable<string> {
    // For POST requests, the headers go as the third argument
    return this.http.post(`${this.apiUrl}/save`, product, { headers: this.getAuthHeaders(), responseType: 'text' });
  }

  updateProduct(product: any): Observable<any> {
    // For PUT requests, the headers go as the third argument
    return this.http.put<any>(`${this.apiUrl}/update`, product, { headers: this.getAuthHeaders() });
  }

  deleteProduct(productId: number): Observable<string> {
    // For DELETE requests, the headers go as the second argument (options object)
    return this.http.delete(`${this.apiUrl}/delete/${productId}`, { headers: this.getAuthHeaders(), responseType: 'text' });
  }

  getProductById(productId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/fetchById/${productId}`, { headers: this.getAuthHeaders() });
  }
}