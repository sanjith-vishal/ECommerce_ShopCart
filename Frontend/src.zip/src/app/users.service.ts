import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CommonService } from './common.service';

// Interface to match your backend User model
export interface UserProfile {
  userId: number;
  name: string;
  email: string;
  phoneNumber: string;
  shippingAddress: string;
}

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  private userApiUrl = 'http://localhost:9090/user';

  constructor(private http: HttpClient, private commonService: CommonService) { }

  private getAuthHeaders(): HttpHeaders {
    let token: string | null = null;
    if (typeof localStorage !== 'undefined') {
      token = localStorage.getItem('token');
    }
    let headers = new HttpHeaders();
    if (token) {
      headers = headers.set('Authorization', 'Bearer ' + token);
    }
    return headers;
  }

  getAllUsers(): Observable<UserProfile[]> {
    return this.http.get<UserProfile[]>(`${this.userApiUrl}/fetchAll`, { headers: this.getAuthHeaders() }).pipe(
      catchError(error => {
        console.error('Error fetching all users:', error);
        return throwError(() => new Error(`Failed to fetch users: ${error.message || 'Server error'}`));
      })
    );
  }

  getUserById(userId: number): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.userApiUrl}/fetchById/${userId}`, { headers: this.getAuthHeaders() }).pipe(
      catchError(error => {
        console.error(`Error fetching user details for ID ${userId}:`, error);
        return throwError(() => new Error(`Failed to fetch user details: ${error.message || 'Server error'}`));
      })
    );
  }

  // Renamed the parameter from 'user' to 'userProfile' for clarity
  // This method now only sends profile data, no password
  saveUser(userProfile: UserProfile): Observable<string> {
    // This is now redundant for new user creation if registerService.registerBoth1 is used.
    // It will only be used by registerService internally now.
    // However, if you had a separate admin-only "save profile without auth" endpoint, you could use this.
    return this.http.post(`${this.userApiUrl}/save`, userProfile, { headers: this.getAuthHeaders(), responseType: 'text' }).pipe(
      catchError(error => {
        console.error('Error saving user profile:', error);
        return throwError(() => error);
      })
    );
  }

  updateUser(userProfile: UserProfile): Observable<UserProfile> {
    return this.http.put<UserProfile>(`${this.userApiUrl}/update`, userProfile, { headers: this.getAuthHeaders() }).pipe(
      catchError(error => {
        console.error('Error updating user profile:', error);
        return throwError(() => error);
      })
    );
  }

  deleteUser(userId: number): Observable<string> {
    return this.http.delete(`${this.userApiUrl}/delete/${userId}`, { headers: this.getAuthHeaders(), responseType: 'text' }).pipe(
      catchError(error => {
        console.error(`Error deleting user profile with ID ${userId}:`, error);
        return throwError(() => error);
      })
    );
  }
}